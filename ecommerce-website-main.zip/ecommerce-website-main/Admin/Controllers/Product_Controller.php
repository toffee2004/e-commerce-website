<?php
require_once './Models/Brand_Model.php';
require_once './Models/Category_Model.php';
require_once './Models/Product_Model.php';
class ProductController {
    public function index() {
        
    
        // If 'status' is not set in the URL, redirect to the URL with 'status=all'
        if (empty($_GET['status'])) {
            header("Location: ./index.php?controller=product&action=index&status=all");
            exit();
        }
    
        // Get the status, defaulting to 'all' if not set
        $productmodel = new ProductModel();

        $status = $_GET['status'] ?? 'all'; 
        $products = $productmodel->getByStatus($status);

        include './Views/ListProducts.php';
    }
    
    public function toggleStatus() {
        if (isset($_GET['id']) && isset($_GET['status'])) {
            $id = $_GET['id'];
            $status = $_GET['status'];
            $Productmodel = new ProductModel();
            
            // Call a method to update the brand's status
            if ($Productmodel->updateStatus($id, $status)) {
                header("Location: ./index.php?controller=product&action=index");
                exit();
            } else {
                echo "Error updating product status.";
            }
        }
    }
    public function add() {

        $brandmodel = new BrandModel();
        $brands = $brandmodel->getByStatus('all'); // Lấy danh sách thương hiệu từ model
        
        $categorymodel = new CategoryModel();
        $categories = $categorymodel->getByStatus('all'); // Lấy danh sách danh mục từ model
        include './Views/AddProduct.php';
    }
    public function store() {
        $product = new ProductModel;
    
        $product->name = $_POST['name'];
        $product->slug = $_POST['slug'];
        $product->summary = $_POST['summary'];
        $product->description = $_POST['description'];
        $product->price = $_POST['price'];
        $product->price_vip1 = $_POST['price_vip1'];
        $product->price_vip2 = $_POST['price_vip2'];

        $product->category_id = $_POST['category_id'];
        $product->brand_id = $_POST['brand_id'];
        $product->countfiles = count($_FILES['images']['name']);
        
        $product->images = '';
        for ($i = 0; $i < $product->countfiles; $i++) {
            $filename = $_FILES['images']['name'][$i];

            ## Location
            $location = "../Uploads/" . uniqid() . $filename;
            //pathinfo ( string $path [, int $options = PATHINFO_DIRNAME | PATHINFO_BASENAME | PATHINFO_EXTENSION | PATHINFO_FILENAME ] ) : mixed
            $extension = pathinfo($location, PATHINFO_EXTENSION);
            $extension = strtolower($extension);

            ## File upload allowed extensions
            $valid_extensions = array("jpg", "jpeg", "png");

            $response = 0;
            ## Check file extension
            if (in_array(strtolower($extension), $valid_extensions)) {

                // them vao CSDL - them thah cong moi upload anh len
                ## Upload file
                //$_FILES['file']['tmp_name']: $_FILES['file']['tmp_name'] - The temporary filename of the file in which the uploaded file was stored on the server.
                if (move_uploaded_file($_FILES['images']['tmp_name'][$i], $location)) {

                    $product->images .= $location . ";";
                }
            }

        }
        $product->images = substr($product->images, 0, -1);

        // echo substr($images, 0, -1); exit;
        if ($product->insert()) {
            $slug = $product->slug; // Hoặc $_POST['slug'] sau khi lưu DB
            $friendlyUrl = "http://localhost/Public/san-pham/$slug.html";
            $outputPath = __DIR__ . "/../../Public/san-pham/$slug.html"; // đường dẫn vật lý lưu file

            $product->generateStaticFromFriendlyURL($friendlyUrl, $outputPath);
            $this->index(); //
            // header("Location: ./index.php?controller=product&action=index"); // Chuyển hướng về danh sách sản phẩm
        } else {
            echo "Lỗi khi thêm sản phẩm.";
        }
    }
    public function update() {

        $product = new ProductModel;
        $id = $_POST['id'];
        $product->name = $_POST['name'];
        $product->slug = $_POST['slug'];
        $product->summary = $_POST['summary'];
        $product->description = $_POST['description'];
        $product->stock = $_POST['stock'];
        $product->price = $_POST['price'];
        $product->price_vip1 = $_POST['price_vip1'];
        $product->price_vip2 = $_POST['price_vip2'];
        $product->category_id = $_POST['category_id'];
        $product->brand_id = $_POST['brand_id'];
    
        // Lấy danh sách ảnh được gửi từ form
        $imageList = isset($_POST['imageList']) ? explode(';', $_POST['imageList']) : [];
        $oldImages = $product->getImagesById($id);
        $oldImages = explode(";", $oldImages);
    
        // Khởi tạo danh sách ảnh mới
        $newImages = [];
        
        // Duyệt qua danh sách ảnh cũ để giữ lại những ảnh không bị xóa
        foreach ($oldImages as $oldImage) {
            if (in_array($oldImage, $imageList)) {
                $newImages[] = $oldImage;
            } else {
                if ($product->countProductsUsingImage($oldImage) <= 1) {
                    if (file_exists($oldImage)) {
                        unlink($oldImage);
                    }
                }
            }
        }
        
    
        // Xử lý các ảnh mới được upload
        if (!empty($_FILES['images']['name'][0])) {
            $product->countfiles = count($_FILES['images']['name']);
            
            for ($i = 0; $i < $product->countfiles; $i++) {
                $filename = $_FILES['images']['name'][$i];
                $location = "../Uploads/" . $filename;
                $extension = pathinfo($location, PATHINFO_EXTENSION);
                $extension = strtolower($extension);
    
                // Các định dạng file hợp lệ
                $valid_extensions = ["jpg", "jpeg", "png"];
    
                if (in_array($extension, $valid_extensions)) {
                    if (move_uploaded_file($_FILES['images']['tmp_name'][$i], $location)) {
                        $newImages[] = $location;
                    }
                }
            }
        }
    
        // Gán lại danh sách ảnh sau khi xử lý
        $product->images = implode(";", $newImages);
    
        // Cập nhật cơ sở dữ liệu
        if ($product->update($id)) {
            $slug = $product->slug; // Hoặc $_POST['slug'] sau khi lưu DB
            $friendlyUrl = "http://localhost/Public/san-pham/$slug.html";
            $outputPath = __DIR__ . "/../../Public/san-pham/$slug.html"; // đường dẫn vật lý lưu file

            $product->generateStaticFromFriendlyURL($friendlyUrl, $outputPath);
            $this->index();
        } else {
            echo "Lỗi khi cập nhật sản phẩm.";
        }
    }
    
    
    
    
    public function edit() {
        $brandmodel = new BrandModel();
        $brands = $brandmodel->getByStatus('all'); // Lấy danh sách thương hiệu từ model
        $categorymodel = new CategoryModel();
        $categories = $categorymodel->getByStatus('all'); // Lấy danh sách danh mục từ model
        $productmodel = new ProductModel();
    
        $id = $_GET['id']; // Lấy id từ URL
        $product = $productmodel->getById($id); // Gọi hàm lấy dữ liệu trong model
    
        include './Views/EditProduct.php'; // Truyền biến $brand sang View
    }
    
    
}
