<?php
require("Includes/Header.php"); 
?>
<?php

echo "<pre>";
print_r($_SESSION); // In tất cả các giá trị trong session
echo "</pre>";
?>

 <?php
 require("Includes/Footer.php");
 ?>