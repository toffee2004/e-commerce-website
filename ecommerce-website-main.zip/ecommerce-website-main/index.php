<?php
// Redirect đến giao diện người dùng mặc định
header("Location: Public/index.php");
exit;
